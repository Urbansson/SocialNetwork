/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.social.handlers;

/**
 *
 * @author Teddy
 */
public class userHandler {
    
    public userHandler(){
    
    }
    
    public static boolean login(String username, String password){
    
        return false;
    }
    
}
